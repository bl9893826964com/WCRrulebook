import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const RailGyanApp());

class RailGyanApp extends StatelessWidget {
  const RailGyanApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WCR Rule Book',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF123B63)),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const LibraryHome(),
    );
  }
}

class LibraryHome extends StatefulWidget {
  const LibraryHome({super.key});
  @override
  State<LibraryHome> createState() => _LibraryHomeState();
}

class _LibraryHomeState extends State<LibraryHome> {
  Map<String, dynamic>? data;
  String query = '';
  String division = 'सभी मंडल';
  Set<String> bookmarks = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/library.json');
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      data = jsonDecode(raw) as Map<String, dynamic>;
      bookmarks = (prefs.getStringList('bookmarks') ?? []).toSet();
      loading = false;
    });
  }

  Future<void> _toggleBookmark(String id) async {
    setState(() {
      if (!bookmarks.add(id)) bookmarks.remove(id);
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('bookmarks', bookmarks.toList());
  }

  List<Map<String, dynamic>> get categories {
    final all = (data?['categories'] as List? ?? []).cast<Map<String, dynamic>>();
    return all.where((c) {
      final matchesDivision = division == 'सभी मंडल' ||
          c['division'] == 'सभी मंडल' || c['division'] == division;
      final text = '${c['name']} ${c['description']} ${c['division']}'.toLowerCase();
      return matchesDivision && text.contains(query.toLowerCase());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('WCR RULE BOOK', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('पश्चिम मध्य रेलवे रूल बुक', style: TextStyle(fontSize: 11)),
        ]),
        actions: [
          IconButton(
            tooltip: 'बुकमार्क',
            icon: const Icon(Icons.bookmark),
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => BookmarkPage(ids: bookmarks.toList(), onToggle: _toggleBookmark),
            )),
          )
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF123B63), Color(0xFF2875A8)]),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('रेलवे नियम और जानकारी', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('भोपाल • जबलपुर • कोटा', style: TextStyle(color: Colors.white70)),
                  SizedBox(height: 8),
                  Text('ऑफलाइन हिंदी संदर्भ पुस्तकालय', style: TextStyle(color: Colors.white)),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: InputDecoration(
                    hintText: 'नियम, विषय या अध्याय खोजें',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: DropdownButtonFormField<String>(
                  value: division,
                  decoration: const InputDecoration(labelText: 'मंडल चुनें', border: OutlineInputBorder()),
                  items: ['सभी मंडल', 'भोपाल', 'जबलपुर', 'कोटा']
                      .map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                  onChanged: (v) => setState(() => division = v ?? 'सभी मंडल'),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: categories.length,
                  itemBuilder: (context, i) {
                    final c = categories[i];
                    final id = c['id'] as String;
                    return Card(
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.menu_book)),
                        title: Text(c['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text('${c['division']} • ${c['description']}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => CategoryPage(category: c, isSaved: bookmarks.contains(id), onToggle: () => _toggleBookmark(id)),
                        )),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: Text(data?['notice'] ?? '', textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.deepOrange)),
              )
            ]),
    );
  }
}

class CategoryPage extends StatelessWidget {
  final Map<String, dynamic> category;
  final bool isSaved;
  final VoidCallback onToggle;
  const CategoryPage({super.key, required this.category, required this.isSaved, required this.onToggle});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(category['name']), actions: [
      IconButton(icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_border), onPressed: onToggle)
    ]),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Chip(label: Text(category['division'])),
        const SizedBox(height: 12),
        Text(category['description'], style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 20),
        const Text('इस विषय की प्रमाणित सामग्री अगले चरण में जोड़ी जाएगी।'),
        const SizedBox(height: 12),
        const Text('कृपया नवीनतम अधिकृत WCR / रेलवे बोर्ड नियम-पुस्तिका और संशोधन के आधार पर ही सामग्री प्रकाशित करें।'),
      ]),
    ),
  );
}

class BookmarkPage extends StatelessWidget {
  final List<String> ids;
  final Future<void> Function(String) onToggle;
  const BookmarkPage({super.key, required this.ids, required this.onToggle});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('मेरे बुकमार्क')),
    body: ids.isEmpty
      ? const Center(child: Text('अभी कोई बुकमार्क नहीं है।'))
      : ListView(children: ids.map((id) => ListTile(
          leading: const Icon(Icons.bookmark),
          title: Text(id),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => onToggle(id)),
        )).toList()),
  );
}
